<!DOCTYPE html>
<?php
	session_start();
	include('f1c_var.php');
	include('fonctions.php');
	connectBD();
?>
<html lang="en-US"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">




<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="profile" href="http://gmpg.org/xfn/11">

<link rel="pingback" href="http://streetlingua.com/xmlrpc.php">

<title>STREETLINGUA</title>
<link rel="dns-prefetch" href="http://fonts.googleapis.com/">
<link rel="dns-prefetch" href="http://s.w.org/">
<link rel="alternate" type="application/rss+xml" title="STREETLINGUA » Feed" href="http://streetlingua.com/index.php/feed/">
<link rel="alternate" type="application/rss+xml" title="STREETLINGUA » Comments Feed" href="http://streetlingua.com/index.php/comments/feed/">
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/streetlingua.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.7.4"}};
			!function(a,b,c){function d(a){var b,c,d,e,f=String.fromCharCode;if(!k||!k.fillText)return!1;switch(k.clearRect(0,0,j.width,j.height),k.textBaseline="top",k.font="600 32px Arial",a){case"flag":return k.fillText(f(55356,56826,55356,56819),0,0),!(j.toDataURL().length<3e3)&&(k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,65039,8205,55356,57096),0,0),b=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,55356,57096),0,0),c=j.toDataURL(),b!==c);case"emoji4":return k.fillText(f(55357,56425,55356,57341,8205,55357,56507),0,0),d=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55357,56425,55356,57341,55357,56507),0,0),e=j.toDataURL(),d!==e}return!1}function e(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i,j=b.createElement("canvas"),k=j.getContext&&j.getContext("2d");for(i=Array("flag","emoji4"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script><script src="./STREETLINGUA_files/wp-emoji-release.min.js.download" type="text/javascript" defer=""></script>
		<script type="text/javascript" src="./index.js"></script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<!--<link rel="stylesheet" id="dashicons-css" href="./STREETLINGUA_files/dashicons.min.css" type="text/css" media="all">
<link rel="stylesheet" id="admin-bar-css" href="./STREETLINGUA_files/admin-bar.min.css" type="text/css" media="all">-->
<link rel="stylesheet" id="zerif_font-css" href="./style.css" type="text/css" media="all">
<link rel="stylesheet" id="zerif_font_all-css" href="./style.css" type="text/css" media="all">
<link rel="stylesheet" id="zerif_bootstrap_style-css" href="./css/bootstrap.min.css" type="text/css" media="all">
<link rel="stylesheet" id="zerif_font-awesome_style-css" href="./assets/css/font-awesome.min.css" type="text/css" media="all">
<link rel="stylesheet" id="zerif_style-css" href="./style.css" type="text/css" media="all">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>



<style id="zerif_style-inline-css" type="text/css">

.navbar.navbar-inverse .nav.navbar-nav a, .navbar.navbar-inverse .nav.navbar-nav > li > a, .nav.navbar-inverse .nav.navbar-nav ul.sub-menu li a,
		 .navbar.navbar-inverse .primary-menu a, .navbar.navbar-inverse .primary-menu > li > a, .nav.navbar-inverse .primary-menu ul.sub-menu li a {
			color:#808080;
		}.navbar.navbar-inverse .nav.navbar-nav a:hover, .navbar.navbar-inverse .nav.navbar-nav > li > a:hover, .nav.navbar-inverse .nav.navbar-nav ul.sub-menu li a:hover,
		 .navbar.navbar-inverse .primary-menu a:hover, .navbar.navbar-inverse .primary-menu > li > a:hover, .nav.navbar-inverse .primary-menu ul.sub-menu li a:hover {
			color:#e96656;
		}
		.screen-reader-text {
			clip: rect(1px, 1px, 1px, 1px);
			position: absolute !important;
		}
		.screen-reader-text:hover,
		.screen-reader-text:active,
		.screen-reader-text:focus {
			background-color: #f1f1f1;
			border-radius: 3px;
			box-shadow: 0 0 2px 2px rgba(0, 0, 0, 0.6);
			clip: auto !important;
			color: #21759b;
			display: block;
			font-size: 14px;
			font-weight: bold;
			height: auto;
			left: 5px;
			line-height: normal;
			padding: 15px 23px 14px;
			text-decoration: none;
			top: 5px;
			width: auto;
			z-index: 100000; !* Above WP toolbar *!
		}
</style>
<!--[if lt IE 9]>
<link rel='stylesheet' id='zerif_ie_style-css'  href='http://streetlingua.com/wp-content/themes/zerif-pro/css/ie.css?ver=v1' type='text/css' media='all' />
<![endif]-->
<script type="text/javascript" src="./js/jquery.js"></script>
<script type="text/javascript" src="./jquery-migrate.min.js"></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='http://streetlingua.com/wp-content/themes/zerif-pro/js/html5.js?ver=4.7.4'></script>
<![endif]-->
<link rel="https://api.w.org/" href="http://streetlingua.com/index.php/wp-json/">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://streetlingua.com/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://streetlingua.com/wp-includes/wlwmanifest.xml"> 
<meta name="generator" content="WordPress 4.7.4">
		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		<style type="text/css" id="custom-background-css">
body.custom-background { background-image: url("http://streetlingua.com/wp-content/uploads/2017/05/485067920.jpg"); background-position: left top; background-size: cover; background-repeat: no-repeat; background-attachment: fixed; }
</style>
<style type="text/css" media="print">#wpadminbar { display:none; }</style>
<style type="text/css" media="screen">
	html {}
	* html body { margin-top: 32px !important; }
	@media screen and ( max-width: 782px ) {
		html { margin-top: 46px !important; }
		* html body { margin-top: 46px !important; }
	}
</style>


</head>

		<body class="home blog custom-background customize-support" itemscope="itemscope" itemtype="http://schema.org/WebPage">
			
<div class="zerif_full_site_wrap"><div class="fadein-slider"></div><div class="zerif_full_site">		<!-- =========================

		   PRE LOADER

		============================== -->

		
		<header id="home" class="header" itemscope="itemscope" itemtype="http://schema.org/WPHeader" style="opacity: 1; min-height: 50px;">

			
			<div id="main-nav" class="navbar navbar-inverse bs-docs-nav" style="min-height: 111px;">

				<div class="container">

					<div class="navbar-header responsive-logo">

						<button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">

						<span class="screen-reader-text">Menu</span>

						<span class="icon-bar"></span>

						<span class="icon-bar"></span>

						<span class="icon-bar"></span>

						</button>



						
						<div class="navbar-brand">

							<div>
									<h1 class="site-title">
										<a href="http://streetlingua.com/">
											STREETLINGUA										</a>
									</h1>

									
								</div> <!-- /.site-title-tagline-wrapper -->

							
						</div> <!-- /.navbar-brand -->

					</div> <!-- /.navbar-header -->

						<nav id="site-navigation" itemscope="" itemtype="http://schema.org/SiteNavigationElement">
		<!--<ul id="menu-le-concept" class="nav navbar-nav navbar-right responsive-nav main-nav-list"><li id="menu-item-15" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15">
		<a href="#focus">Le concept</a>
-->
<div class="buttons"><a href="./connexion3.php" class="btn btn-primary custom-button blue-btn" >Connexion</a>
<a href="./inscription.php" class="btn btn-primary custom-button blue-btn" >Inscription</a></div></nav>
	



				</div>

			</div>
						<!-- / END TOP BAR -->
<div class="home-header-wrap">

<div class="header-content-wrap">
<div class="container big-title-container">
<h4 style="color:white">Développe ton English en échangeant avec des anglophones près de chez toi !</h4>
<h1 class="intro-text">STREET LINGUA</h1>
<br>
<h4 style="color :white">Je veux apprendre</h4>
<div class="buttons">
<a href="#" class="btn btn-primary custom-button red-btn" >Je teste le concept !</a></div>
</div>


</div><!-- .header-content-wrap -->


<!--modal popup pour l'identification-->
  <!-- Modal -->
 
  <!-------------->
</div>

</body>


</div><!--.home-header-wrap -->

</header> <!-- / END HOME SECTION  -->
<div id="content" class="site-content zerif-fp-site-content">

	<section class="focus" id="focus"><div class="container"><div class="section-header"><h2 class="dark-text">Le concept</h2><h6>Grandir vite!</h6></div><!-- .section-header --><div class="row"><span id="text-3"><h1 class="widget-title">Un problème identifié …</h1>			<div class="textwidget"><p>Tout le monde le sait, la meilleure façon d'apprendre une langue est bel et bien de la parler. Trop souvent, les gens se contentent d'étudier la grammaire et d'apprendre des listes de vocabulaire plutôt que de sortir de chez eux et d'essayer de parler réellement la langue. Tu décides donc de bouger, de voyager et de faire des tonnes de rencontres ! Mais cette option est parfois trop coûteuse … Tu souhaites donc échanger avec des bilingues près de chez toi ? Une sorte de séjour linguistique à domicile ?</p>
</div>
		</span><span id="text-4"><h1 class="widget-title">… une solution appropriée !</h1>			<div class="textwidget">C’est pourquoi nous avons créé Street Lingua. Cette plateforme d’échange entre bilingues et apprentis privilégie l’aspect humain et le relationnel avant tout. Quoi de plus enrichissant que de rencontrer un anglophone pour échanger avec lui autour d'un cours de cuisine, en prenant un verre ou en observant les étoiles ?!</div>
		</span></div></div> <!-- / END CONTAINER --></section>  <!-- / END FOCUS SECTION -->
					
												<section class="contact-us" id="contact">
							<div class="container">
								<!-- SECTION HEADER -->
								<div class="section-header">
									<h2 class="white-text">Get in touch</h2>								</div>
								<!-- / END SECTION HEADER -->

								
									<!-- CONTACT FORM-->
									<div class="row">

										
										<form role="form" method="POST" action="http://streetlingua.com/" onsubmit="this.scrollPosition.value=(document.body.scrollTop || document.documentElement.scrollTop)" class="contact-form">

											<input type="hidden" name="scrollPosition">

											<input type="hidden" name="submitted" id="submitted" value="true">

											<div class="col-lg-4 col-sm-4 zerif-rtl-contact-name" data-scrollreveal="enter left after 0s over 1s" style="-webkit-transform: translatex(-60px);-moz-transform: translatex(-60px);-ms-transform: translatex(-60px);transform: translatex(-60px);opacity: 0;" data-sr-init="true">

																								
												<input type="text" name="myname" placeholder="Your Name" class="form-control input-box" value="">

											</div>

											<div class="col-lg-4 col-sm-4 zerif-rtl-contact-email" data-scrollreveal="enter left after 0s over 1s" style="-webkit-transform: translatex(-60px);-moz-transform: translatex(-60px);-ms-transform: translatex(-60px);transform: translatex(-60px);opacity: 0;" data-sr-init="true">

																																				<input type="email" name="myemail" placeholder="Your Email" class="form-control input-box" value="">

											</div>

											<div class="col-lg-4 col-sm-4 zerif-rtl-contact-subject" data-scrollreveal="enter left after 0s over 1s" style="-webkit-transform: translatex(-60px);-moz-transform: translatex(-60px);-ms-transform: translatex(-60px);transform: translatex(-60px);opacity: 0;" data-sr-init="true">

												
																								<input type="text" name="mysubject" placeholder="Subject" class="form-control input-box" value="">

											</div>

											<div class="col-lg-12 col-sm-12" data-scrollreveal="enter right after 0s over 1s" style="-webkit-transform: translatex(60px);-moz-transform: translatex(60px);-ms-transform: translatex(60px);transform: translatex(60px);opacity: 0;" data-sr-init="true">

												
																								<textarea name="mymessage" class="form-control textarea-box" placeholder="Your Message"></textarea>

											</div>

											<button class="btn btn-primary custom-button red-btn" type="submit" data-scrollreveal="enter left after 0s over 1s" style="-webkit-transform: translatex(-60px);-moz-transform: translatex(-60px);-ms-transform: translatex(-60px);transform: translatex(-60px);opacity: 0;" data-sr-init="true">Send Message</button>
											
										</form>

									</div>

									<!-- / END CONTACT FORM-->
									
							</div> <!-- / END CONTAINER -->

						</section> <!-- / END CONTACT US SECTION-->
							<div class="zerif_shortcodes" id="shortcodes-section">

</div><!-- .site-content -->

<footer id="footer" itemscope="itemscope" itemtype="http://schema.org/WPFooter">

	
<div class="container">
	
	

	<div class="footer-box-wrap">
		<div class="col-md-3 footer-box four-cell company-details"><div class="icon-top red-text"><img src="./STREETLINGUA_files/map25-redish.png" alt=""></div><div class="zerif-footer-address">Company address</div></div><div class="col-md-3 footer-box four-cell company-details"><div class="icon-top green-text"><img src="./STREETLINGUA_files/envelope4-green.png" alt=""></div><div class="zerif-footer-email"><a href="mailto:contact@site.com">contact@site.com</a></div></div><div class="col-md-3 footer-box four-cell company-details"><div class="icon-top blue-text"><img src="./STREETLINGUA_files/telephone65-blue.png" alt=""></div><div class="zerif-footer-phone"><a href="tel:0 332 548 954">0 332 548 954</a></div></div>			<div class="col-md-3 footer-box four-cell copyright">
									<ul class="social">
								<li>
			<a target="_blank" title="Facebook link" href="http://streetlingua.com/#">
								<i class="fa fa-facebook"></i>
			</a>
		</li>
				<li>
			<a target="_blank" title="Twitter link" href="http://streetlingua.com/#">
								<i class="fa fa-twitter"></i>
			</a>
		</li>
				<li>
			<a target="_blank" title="Linkedin link" href="http://streetlingua.com/#">
								<i class="fa fa-linkedin"></i>
			</a>
		</li>
				<li>
			<a target="_blank" title="Behance link" href="http://streetlingua.com/#">
								<i class="fa fa-behance"></i>
			</a>
		</li>
				<li>
			<a target="_blank" title="Dribbble link" href="http://streetlingua.com/#">
								<i class="fa fa-dribbble"></i>
			</a>
		</li>
							</ul>
								</div>
				</div>

	</div> <!-- / END CONTAINER -->

</footer> <!-- / END FOOOTER  -->


</div><!-- .zerif_full_site --></div><!-- .zerif_full_site_wrap --> <style type="text/css">	.site-content { background: #fff } .navbar, .navbar-inverse .navbar-nav ul.sub-menu { background: #fff; }	.entry-title, .entry-title a, .widget-title, .widget-title a, .page-header .page-title, .comments-title, h1.page-title { color: #404040 !important}	.widget .widget-title:before, .entry-title:before, .page-header .page-title:before, .entry-title:after, ul.nav > li.current_page_item > a:before, .nav > li.current-menu-item > a:before, h1.page-title:before, .navbar.navbar-inverse .primary-menu ul li.current-menu-item > a:before, ul.nav > li > a.nav-active:before, .navbar.navbar-inverse .primary-menu ul > li.current > a:before { background: #e96656 !important; }	body, button, input, select, textarea, .widget p, .widget .textwidget, .woocommerce .product h3, .woocommerce .product span.amount, .woocommerce-page .woocommerce .product-name a { color: #404040 }	.widget li a, .widget a, article .entry-meta a, .entry-footer a { color: #808080; }	.header-content-wrap { background: rgba(0, 0, 0, 0.5)}	.big-title-container .intro-text { color: #fff}	.big-title-container .red-btn { background: #e96656}	.big-title-container .red-btn:hover { background: #cb4332}	.big-title-container .buttons .red-btn { color: #fff !important }	.big-title-container .green-btn { background: #20AA73}	.big-title-container .green-btn:hover { background: #069059}	.big-title-container .buttons .green-btn { color:  !important }	.big-title-container .red-btn:hover { color: #fff !important }	.big-title-container .green-btn:hover { color: #fff !important }	.focus { background: rgba(255, 255, 255, 1) }	.focus .section-header h2{ color: #404040 }	.focus .section-header h6{ color: #404040 }	.focus .focus-box h5{ color: #404040 }	.focus .focus-box p{ color: #404040 }	#focus span:nth-child(4n+1) .focus-box .service-icon:hover { border: 10px solid #e96656 }	#focus span:nth-child(4n+1) .focus-box .red-border-bottom:before{ background: #e96656 }	#focus span:nth-child(4n+2) .focus-box .service-icon:hover { border: 10px solid #34d293 }	#focus span:nth-child(4n+2) .focus-box .red-border-bottom:before { background: #34d293 }	#focus span:nth-child(4n+3) .focus-box .service-icon:hover { border: 10px solid #3ab0e2 }	#focus span:nth-child(4n+3) .focus-box .red-border-bottom:before { background: #3ab0e2 }	#focus span:nth-child(4n+4) .focus-box .service-icon:hover { border: 10px solid #f7d861 }	#focus span:nth-child(4n+4) .focus-box .red-border-bottom:before { background: #f7d861 }	.works { background: rgba(255, 255, 255, 1) }	.works .section-header h2 { color: #404040 }	.works .section-header h6 { color: #404040 }	.works .white-text { color: #fff }.works .red-border-bottom:before { background: #e96656 !important; }	.about-us, .about-us .our-clients .section-footer-title { background: rgba(39, 39, 39, 1) }	.about-us { color: #fff }	.about-us p{ color: #fff }	.about-us .section-header h2, .about-us .section-header h6 { color: #fff }.about-us	.skills input { color: #fff !important; }.about-us .our-clients .section-footer-title { color: #fff !important; }	.our-team { background: rgba(255, 255, 255, 1) }	.our-team .section-header h2, .our-team .member-details h5, .our-team .member-details h5 a, .our-team .section-header h6, .our-team .member-details .position { color: #404040 }	.our-team .team-member:hover .details { color: #fff }	.our-team .team-member .social-icons ul li a:hover { color: #e96656 }	.our-team .team-member .social-icons ul li a { color: #808080 }.team-member:hover .details { background: #333 !important; }	.our-team .row > span:nth-child(4n+1) .red-border-bottom:before { background: #e96656 }	.our-team .row > span:nth-child(4n+2) .red-border-bottom:before { background: #34d293 }	.our-team .row > span:nth-child(4n+3) .red-border-bottom:before { background: #3ab0e2 }	.our-team .row > span:nth-child(4n+4) .red-border-bottom:before { background: #f7d861 }	.testimonial { background: rgba(219, 191, 86, 1) }	.testimonial .section-header h2, .testimonial .section-header h6 { color: #fff }	.testimonial .feedback-box .message { color: #909090 }	.testimonial .feedback-box .client-info .client-name { color: #909090 }	.testimonial .feedback-box .quote { color: #e96656 }	#client-feedbacks .feedback-box { background: #FFFFFF; }	.separator-one { background: rgba(52, 210, 147, 0.8) }	.separator-one h3 { color: #fff !important; }	.separator-one .green-btn { background: #20AA73 }	.separator-one .green-btn:hover { background: #14a168 }	.separator-one .green-btn { color: #fff !important; }	.separator-one .green-btn:hover { color: #fff !important; }	.purchase-now { background: rgba(233, 102, 86, 1) }	.purchase-now h3 { color: #fff }	.purchase-now .red-btn { background: #db5a4a !important }	.purchase-now .red-btn:hover { background: #bf3928 !important }	.purchase-now .red-btn { color: #fff !important; }	.purchase-now .red-btn:hover { color: #fff !important; }	.contact-us { background: rgba(0, 0, 0, 0.5) }	.contact-us .section-header h2, .contact-us .section-header h6 { color: #fff }	.contact-us button { background: #e96656 }	.contact-us button:hover { background: #cb4332 !important; box-shadow: none; }	.contact-us button, .pirate_forms .pirate-forms-submit-button { color: #fff !important; }	.contact-us button:hover, .pirate_forms .pirate-forms-submit-button:hover { color: #fff !important; }	.packages .section-header h2, .packages .section-header h6 { color: #fff}	.packages .package-header h5,.best-value .package-header h4,.best-value .package-header .meta-text { color: #fff}	.packages .package ul li, .packages .price .price-meta { color: #808080}	.packages .package .custom-button { color: #fff !important; }	.packages .dark-bg { background: #404040; }	.packages .price h4 { color: #fff; }	.packages { background: rgba(0, 0, 0, 0.5) }	#latestnews { background: rgba(255, 255, 255, 1) }	#latestnews .section-header h2 { color: #404040 }	#latestnews .section-header h6 { color: #808080 }	#latestnews #carousel-homepage-latestnews .carousel-inner .item .latestnews-title a { color: #404040}	#latestnews #carousel-homepage-latestnews .item .latestnews-box:nth-child(4n+1) .latestnews-title a:before { background: #e96656}	#latestnews #carousel-homepage-latestnews .item .latestnews-box:nth-child(4n+2) .latestnews-title a:before { background: #34d293}	#latestnews #carousel-homepage-latestnews .item .latestnews-box:nth-child(4n+3) .latestnews-title a:before { background: #3ab0e2}	#latestnews #carousel-homepage-latestnews .item .latestnews-box:nth-child(4n+4) .latestnews-title a:before { background: #f7d861}	#latestnews .latesnews-content p, .latesnews-content { color: #909090} section#subscribe { background: rgba(0, 0, 0, 0.5) !important; } section#subscribe h3, .newsletter .sub-heading, .newsletter label { color: #fff !important; } section#subscribe input[type="submit"] { color: #fff !important; } section#subscribe input[type="submit"] { background: #e96656 !important; } section#subscribe input[type="submit"]:hover { background: #cb4332 !important; }	#footer { background: #272727 }	.copyright { background: #171717 }	#footer .company-details, #footer .company-details a, #footer .footer-widget p, #footer .footer-widget a { color: #939393 !important; }	#footer .social li a { color: #939393 }	#footer .social li a:hover { color: #e96656 }	#footer .company-details:hover, #footer .company-details a:hover, #footer .footer-widget a:hover { color: #e96656 !important; }	#footer .footer-widget h1 { color: #fff !important; }	#footer .footer-widget h1:before { background: #e96656 !important; }	.comment-form #submit, .comment-reply-link,.woocommerce .add_to_cart_button, .woocommerce .checkout-button, .woocommerce .single_add_to_cart_button, .woocommerce #place_order, .edd-submit.button, .page button, .post button, .woocommerce-page .woocommerce input[type="submit"], .woocommerce-page #content input.button, .woocommerce input.button.alt, .woocommerce-page #content input.button.alt, .woocommerce-page input.button.alt, .woocommerce-page .products a.button { background: #e96656 !important; }	.comment-form #submit:hover, .comment-reply-link:hover, .woocommerce .add_to_cart_button:hover, .woocommerce .checkout-button:hover, .woocommerce  .single_add_to_cart_button:hover, .woocommerce #place_order:hover, .edd-submit.button:hover, .page button:hover, .post button:hover, .woocommerce-page .woocommerce input[type="submit"]:hover, .woocommerce-page #content input.button:hover, .woocommerce input.button.alt:hover, .woocommerce-page #content input.button.alt:hover, .woocommerce-page input.button.alt:hover, .woocommerce-page .products a.button:hover { background: #cb4332 !important; box-shadow: none; }	.comment-form #submit, .comment-reply-link, .woocommerce .add_to_cart_button, .woocommerce .checkout-button, .woocommerce .single_add_to_cart_button, .woocommerce #place_order, .edd-submit.button span, .page button, .post button, .woocommerce-page .woocommerce input[type="submit"], .woocommerce-page #content input.button, .woocommerce input.button.alt, .woocommerce-page #content input.button.alt, .woocommerce-page input.button.alt, .woocommerce .button { color: #fff !important }</style><script type="text/javascript" src="./STREETLINGUA_files/admin-bar.min.js.download"></script>
<script type="text/javascript" src="./js/bootstrap.min.js"></script>
<script type="text/javascript">
/* <![CDATA[ */
var zerif_knob_var = {"zerif_aboutus_feature1_color":"#E96656","zerif_aboutus_feature2_color":"#34D293","zerif_aboutus_feature3_color":"#3AB0E2","zerif_aboutus_feature4_color":"#E7AC44"};
/* ]]> */
</script>
<script type="text/javascript" src="./js/jquery.knob.min.js.download"></script>
<script type="text/javascript" src="./js/smoothscroll.min.js.download"></script>
<script type="text/javascript" src="./js/scrollReveal.min.js.download"></script>
<script type="text/javascript" src="./js/zerif.js.download"></script>
<script type="text/javascript" src="./js/wp-embed.min.js.download"></script>
	
		


</div></body></html>