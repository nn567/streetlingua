<!DOCTYPE html>
<!-- saved from url=(0036)http://localhost/www/page-d-exemple/ -->
<html lang="fr-CA"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">




<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="profile" href="http://gmpg.org/xfn/11">

<link rel="pingback" href="http://localhost/www/xmlrpc.php">

<title>Connexion – streetlingua</title>
<link rel="dns-prefetch" href="http://fonts.googleapis.com/">
<link rel="dns-prefetch" href="http://s.w.org/">
<link rel="alternate" type="application/rss+xml" title="streetlingua » Flux" href="http://localhost/www/feed/">
<link rel="alternate" type="application/rss+xml" title="streetlingua » Flux des commentaires" href="http://localhost/www/comments/feed/">
<link rel="alternate" type="application/rss+xml" title="streetlingua » Connexion Flux des commentaires" href="http://localhost/www/page-d-exemple/feed/">
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/localhost\/www\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.7.4"}};
			!function(a,b,c){function d(a){var b,c,d,e,f=String.fromCharCode;if(!k||!k.fillText)return!1;switch(k.clearRect(0,0,j.width,j.height),k.textBaseline="top",k.font="600 32px Arial",a){case"flag":return k.fillText(f(55356,56826,55356,56819),0,0),!(j.toDataURL().length<3e3)&&(k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,65039,8205,55356,57096),0,0),b=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,55356,57096),0,0),c=j.toDataURL(),b!==c);case"emoji4":return k.fillText(f(55357,56425,55356,57341,8205,55357,56507),0,0),d=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55357,56425,55356,57341,55357,56507),0,0),e=j.toDataURL(),d!==e}return!1}function e(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i,j=b.createElement("canvas"),k=j.getContext&&j.getContext("2d");for(i=Array("flag","emoji4"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script><script src="./Connexion – streetlingua_files/wp-emoji-release.min.js.download" type="text/javascript" defer=""></script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<!--<link rel="stylesheet" id="dashicons-css" href="./STREETLINGUA_files/dashicons.min.css" type="text/css" media="all">
<link rel="stylesheet" id="admin-bar-css" href="./STREETLINGUA_files/admin-bar.min.css" type="text/css" media="all">-->
<link rel="stylesheet" id="zerif_font-css" href="./style.css" type="text/css" media="all">
<link rel="stylesheet" id="zerif_font_all-css" href="./style.css" type="text/css" media="all">
<link rel="stylesheet" id="zerif_bootstrap_style-css" href="./css/bootstrap.min.css" type="text/css" media="all">
<link rel="stylesheet" id="zerif_font-awesome_style-css" href="./assets/css/font-awesome.min.css" type="text/css" media="all">
<link rel="stylesheet" id="zerif_style-css" href="./style.css" type="text/css" media="all">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<style id="zerif_style-inline-css" type="text/css">
.navbar.navbar-inverse .nav.navbar-nav a, .navbar.navbar-inverse .nav.navbar-nav > li > a, .nav.navbar-inverse .nav.navbar-nav ul.sub-menu li a,
		 .navbar.navbar-inverse .primary-menu a, .navbar.navbar-inverse .primary-menu > li > a, .nav.navbar-inverse .primary-menu ul.sub-menu li a {
			color:#808080;
		}.navbar.navbar-inverse .nav.navbar-nav a:hover, .navbar.navbar-inverse .nav.navbar-nav > li > a:hover, .nav.navbar-inverse .nav.navbar-nav ul.sub-menu li a:hover,
		 .navbar.navbar-inverse .primary-menu a:hover, .navbar.navbar-inverse .primary-menu > li > a:hover, .nav.navbar-inverse .primary-menu ul.sub-menu li a:hover {
			color:#e96656;
		}
		.screen-reader-text {
			clip: rect(1px, 1px, 1px, 1px);
			position: absolute !important;
		}
		.screen-reader-text:hover,
		.screen-reader-text:active,
		.screen-reader-text:focus {
			background-color: #f1f1f1;
			border-radius: 3px;
			box-shadow: 0 0 2px 2px rgba(0, 0, 0, 0.6);
			clip: auto !important;
			color: #21759b;
			display: block;
			font-size: 14px;
			font-weight: bold;
			height: auto;
			left: 5px;
			line-height: normal;
			padding: 15px 23px 14px;
			text-decoration: none;
			top: 5px;
			width: auto;
			z-index: 100000; !* Above WP toolbar *!
		}
</style>
<!--[if lt IE 9]>
<link rel='stylesheet' id='zerif_ie_style-css'  href='http://localhost/www/wp-content/themes/zerif-pro/css/ie.css?ver=v1' type='text/css' media='all' />
<![endif]-->
<script type="text/javascript" src="./Connexion – streetlingua_files/jquery.js.download"></script>
<script type="text/javascript" src="./Connexion – streetlingua_files/jquery-migrate.min.js.download"></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='http://localhost/www/wp-content/themes/zerif-pro/js/html5.js?ver=4.7.4'></script>
<![endif]-->
<link rel="https://api.w.org/" href="http://localhost/www/wp-json/">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://localhost/www/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://localhost/www/wp-includes/wlwmanifest.xml"> 
<meta name="generator" content="WordPress 4.7.4">
<link rel="canonical" href="http://localhost/www/page-d-exemple/">
<link rel="shortlink" href="http://localhost/www/?p=2">
<link rel="alternate" type="application/json+oembed" href="http://localhost/www/wp-json/oembed/1.0/embed?url=http%3A%2F%2Flocalhost%2Fwww%2Fpage-d-exemple%2F">
<link rel="alternate" type="text/xml+oembed" href="http://localhost/www/wp-json/oembed/1.0/embed?url=http%3A%2F%2Flocalhost%2Fwww%2Fpage-d-exemple%2F&amp;format=xml">
		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		<style type="text/css" media="print">#wpadminbar { display:none; }</style>
<style type="text/css" media="screen">
	html { margin-top: 32px !important; }
	* html body { margin-top: 32px !important; }
	@media screen and ( max-width: 782px ) {
		html { margin-top: 46px !important; }
		* html body { margin-top: 46px !important; }
	}
</style>


</head>

		<body class="page page-id-2 logged-in admin-bar  customize-support" itemscope="itemscope" itemtype="http://schema.org/WebPage">
			
		<!-- =========================

		   PRE LOADER

		============================== -->
		
		
		<header id="home" class="header" itemscope="itemscope" itemtype="http://schema.org/WPHeader" style="opacity: 1; min-height: 76px;">

			
			<div id="main-nav" class="navbar navbar-inverse bs-docs-nav" style="min-height: 76px;">

				<div class="container">

					<div class="navbar-header responsive-logo">

						<button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">

						<span class="screen-reader-text">Menu</span>

						<span class="icon-bar"></span>

						<span class="icon-bar"></span>

						<span class="icon-bar"></span>

						</button>



						
						<div class="navbar-brand">

															<div class="site-title-tagline-wrapper">
									<h1 class="site-title">
										<a href="http://localhost/www/">
											streetlingua										</a>
									</h1>

									
									

									
								</div> <!-- /.site-title-tagline-wrapper -->

							
						</div> <!-- /.navbar-brand -->

					</div> <!-- /.navbar-header -->

						<nav class="navbar-collapse bs-navbar-collapse collapse" id="site-navigation" itemscope="" itemtype="http://schema.org/SiteNavigationElement">
		<ul class="nav navbar-nav navbar-right responsive-nav main-nav-list zerif-nav-menu-callback"><li class="page_item page-item-2 current_page_item"><a href="http://localhost/www/page-d-exemple/">Connexion</a></li>
</ul>	</nav>
	



				</div>

			</div>
						<!-- / END TOP BAR -->
	<div class="clear"></div>
</header> <!-- / END HOME SECTION  -->
	
<div id="content" class="site-content">
	<div class="container" style="min-height: 1px;">
				<div class="content-left-wrap col-md-9">	
				<div id="primary" class="content-area">
			<main itemscope="" itemtype="http://schema.org/WebPageElement" itemprop="mainContentOfPage" id="main" class="site-main">
				


<article id="post-2" class="post-2 page type-page status-publish hentry">

	<header class="entry-header">

		<span class="date updated published">3 mai 2017</span>
		<span class="vcard author byline"><a href="http://localhost/www/author/user/" class="fn">user</a></span>
	
		<h1 class="entry-title" itemprop="headline">Connexion</h1>		
	</header><!-- .entry-header -->

	
	<div class="entry-content">

	<div id="col2">
<h1>Connexion</h1>
<div id="connexion">


<?php
global $_SESSION;
function ajouterActiviteSession($nouvelleActivite) {
		$_SESSION['activite'][] = date("Y-m-d H:i:s").' : '.$nouvelleActivite;
	}
$connexion = mysqli_connect('localhost', 'user', 'password', 'wp_database');
if (isset($_POST['valider']))
{
    $message='';
    if (empty($_POST['pseudo']) || empty($_POST['password']) ) //Oublie d'un champ
    {
        $message = '<p>une erreur s\'est produite pendant votre identification.
	Vous devez remplir tous les champs</p>
	<p>Cliquez <a href="./connexion.php">ici</a> pour revenir</p>';
    }
    else //On verifie le mot de passe
    {
		$pseudo=mysqli_real_escape_string($connexion, $_POST['pseudo']);
		$resultat=mysqli_query($connexion,'SELECT user_login, user_type, user_pass FROM wp_users WHERE user_login=\''.$pseudo.'\';');
        $row=mysqli_fetch_assoc($resultat);
		
	if (($row['user_pass']) == md5($_POST['password'])) // Acces OK !
	{
	    $_SESSION['pseudo'] = $row['user_login'];
		ajouterActiviteSession('ajout de '.$_SESSION['pseudo']);
		echo  $_SESSION['pseudo'];
		//header("location: index.php?page=index1.php");
		$message = '<p>Connexion reussie</p>';
		
		echo "<p>Cliquez <a href='./tableau_de_bord.php'> ici </a> pour acceder au tableau de bord</p>";
		if ($row['user_type']=='mentor')
		echo "<p>Cliquez <a href='./profil_mentor.php'> ici </a> pour acceder a votre profil</p>";
		else echo "<p>Cliquez <a href='./profil_apprenti.php'> ici </a> pour acceder a votre profil</p>";
		
 		
	}
	else // Acces pas OK !
	{
	    $message = '<p>Une erreur s\'est produite 
	    pendant votre identification.<br /> Le mot de passe ou le pseudo 
            entré n\'est pas correcte.</p><p>Cliquez <a style="color:black" href="index.php?page=connexion.php">ici</a> 
	    pour revenir à la page précédente
	    <br /><br />Cliquez <a style="color:black" href="./index.php">ici</a> 
	    pour revenir à la page d accueil</p>';
	}
    }
    echo $message;
	

}
 else {
?>
<form method="post" action="#">
	
<table>
<tr>
	<td><label for="pseudo">Pseudo :</label></td>
	<td><input name="pseudo"  type="text" id="pseudo" /><br /></td>
</tr>
<tr>
	<td><label for="password">Mot de Passe :</label></td>
	<td><input type="password" name="password" id="password" /></td>
</tr>
<tr style="text-align:center;">
			<td colspan=2><br/><br/>
			<input type="submit" name="valider" value="Connexion" />
			</td>
</tr>
<tr style="text-align:center;">
			<td colspan=2><br/><br/>
			<div class="choix">
			<a  href="./inscription.php">Pas encore inscrit ?</a> </div>
			</td>
</tr>
</table>
</form>
</div>

<?php } ?>
</div>


	</div>
	</article></main>
	</div>
	
		


</body></html>