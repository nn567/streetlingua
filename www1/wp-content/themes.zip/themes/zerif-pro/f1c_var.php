<?php
	define('SERVEUR', 'localhost');
	define('UTILISATEURICE', 'user'); // utilisateurice par défaut
	define('MOTDEPASSE', 'password'); // mot de passe par défaut
	define('BDD', 'lif4');
	//define('REP_HISTO', 'historiques/');
?>
