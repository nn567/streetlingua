<!DOCTYPE html>
<!-- saved from url=(0036)http://localhost/www/page-d-exemple/ -->
<html lang="fr-CA"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">




<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="profile" href="http://gmpg.org/xfn/11">

<link rel="pingback" href="http://localhost/www/xmlrpc.php">

<title>Connexion – streetlingua</title>
<link rel="dns-prefetch" href="http://fonts.googleapis.com/">
<link rel="dns-prefetch" href="http://s.w.org/">
<link rel="alternate" type="application/rss+xml" title="streetlingua » Flux" href="http://localhost/www/feed/">
<link rel="alternate" type="application/rss+xml" title="streetlingua » Flux des commentaires" href="http://localhost/www/comments/feed/">
<link rel="alternate" type="application/rss+xml" title="streetlingua » Connexion Flux des commentaires" href="http://localhost/www/page-d-exemple/feed/">
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/localhost\/www\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.7.4"}};
			!function(a,b,c){function d(a){var b,c,d,e,f=String.fromCharCode;if(!k||!k.fillText)return!1;switch(k.clearRect(0,0,j.width,j.height),k.textBaseline="top",k.font="600 32px Arial",a){case"flag":return k.fillText(f(55356,56826,55356,56819),0,0),!(j.toDataURL().length<3e3)&&(k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,65039,8205,55356,57096),0,0),b=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,55356,57096),0,0),c=j.toDataURL(),b!==c);case"emoji4":return k.fillText(f(55357,56425,55356,57341,8205,55357,56507),0,0),d=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55357,56425,55356,57341,55357,56507),0,0),e=j.toDataURL(),d!==e}return!1}function e(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i,j=b.createElement("canvas"),k=j.getContext&&j.getContext("2d");for(i=Array("flag","emoji4"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script><script src="./Connexion – streetlingua_files/wp-emoji-release.min.js.download" type="text/javascript" defer=""></script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<!--<link rel="stylesheet" id="dashicons-css" href="./STREETLINGUA_files/dashicons.min.css" type="text/css" media="all">
<link rel="stylesheet" id="admin-bar-css" href="./STREETLINGUA_files/admin-bar.min.css" type="text/css" media="all">-->
<link rel="stylesheet" id="zerif_font-css" href="./style.css" type="text/css" media="all">
<link rel="stylesheet" id="zerif_font_all-css" href="./style.css" type="text/css" media="all">
<link rel="stylesheet" id="zerif_bootstrap_style-css" href="./css/bootstrap.min.css" type="text/css" media="all">
<link rel="stylesheet" id="zerif_font-awesome_style-css" href="./assets/css/font-awesome.min.css" type="text/css" media="all">
<link rel="stylesheet" id="zerif_style-css" href="./style.css" type="text/css" media="all">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<style id="zerif_style-inline-css" type="text/css">
.navbar.navbar-inverse .nav.navbar-nav a, .navbar.navbar-inverse .nav.navbar-nav > li > a, .nav.navbar-inverse .nav.navbar-nav ul.sub-menu li a,
		 .navbar.navbar-inverse .primary-menu a, .navbar.navbar-inverse .primary-menu > li > a, .nav.navbar-inverse .primary-menu ul.sub-menu li a {
			color:#808080;
		}.navbar.navbar-inverse .nav.navbar-nav a:hover, .navbar.navbar-inverse .nav.navbar-nav > li > a:hover, .nav.navbar-inverse .nav.navbar-nav ul.sub-menu li a:hover,
		 .navbar.navbar-inverse .primary-menu a:hover, .navbar.navbar-inverse .primary-menu > li > a:hover, .nav.navbar-inverse .primary-menu ul.sub-menu li a:hover {
			color:#e96656;
		}
		.screen-reader-text {
			clip: rect(1px, 1px, 1px, 1px);
			position: absolute !important;
		}
		.screen-reader-text:hover,
		.screen-reader-text:active,
		.screen-reader-text:focus {
			background-color: #f1f1f1;
			border-radius: 3px;
			box-shadow: 0 0 2px 2px rgba(0, 0, 0, 0.6);
			clip: auto !important;
			color: #21759b;
			display: block;
			font-size: 14px;
			font-weight: bold;
			height: auto;
			left: 5px;
			line-height: normal;
			padding: 15px 23px 14px;
			text-decoration: none;
			top: 5px;
			width: auto;
			z-index: 100000; !* Above WP toolbar *!
		}
</style>
<!--[if lt IE 9]>
<link rel='stylesheet' id='zerif_ie_style-css'  href='http://localhost/www/wp-content/themes/zerif-pro/css/ie.css?ver=v1' type='text/css' media='all' />
<![endif]-->
<script type="text/javascript" src="./Connexion – streetlingua_files/jquery.js.download"></script>
<script type="text/javascript" src="./Connexion – streetlingua_files/jquery-migrate.min.js.download"></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='http://localhost/www/wp-content/themes/zerif-pro/js/html5.js?ver=4.7.4'></script>
<![endif]-->
<link rel="https://api.w.org/" href="http://localhost/www/wp-json/">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://localhost/www/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://localhost/www/wp-includes/wlwmanifest.xml"> 
<meta name="generator" content="WordPress 4.7.4">
<link rel="canonical" href="http://localhost/www/page-d-exemple/">
<link rel="shortlink" href="http://localhost/www/?p=2">
<link rel="alternate" type="application/json+oembed" href="http://localhost/www/wp-json/oembed/1.0/embed?url=http%3A%2F%2Flocalhost%2Fwww%2Fpage-d-exemple%2F">
<link rel="alternate" type="text/xml+oembed" href="http://localhost/www/wp-json/oembed/1.0/embed?url=http%3A%2F%2Flocalhost%2Fwww%2Fpage-d-exemple%2F&amp;format=xml">
		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		<style type="text/css" media="print">#wpadminbar { display:none; }</style>
<style type="text/css" media="screen">
	html { margin-top: 32px !important; }
	* html body { margin-top: 32px !important; }
	@media screen and ( max-width: 782px ) {
		html { margin-top: 46px !important; }
		* html body { margin-top: 46px !important; }
	}
</style>


</head>

		<body class="page page-id-2 logged-in admin-bar  customize-support" itemscope="itemscope" itemtype="http://schema.org/WebPage">
			
		<!-- =========================

		   PRE LOADER

		============================== -->
		
		
		<header id="home" class="header" itemscope="itemscope" itemtype="http://schema.org/WPHeader" style="opacity: 1; min-height: 76px;">

			
			<div id="main-nav" class="navbar navbar-inverse bs-docs-nav" style="min-height: 76px;">

				<div class="container">

					<div class="navbar-header responsive-logo">

						<button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">

						<span class="screen-reader-text">Menu</span>

						<span class="icon-bar"></span>

						<span class="icon-bar"></span>

						<span class="icon-bar"></span>

						</button>



						
						<div class="navbar-brand">

															<div class="site-title-tagline-wrapper">
									<h1 class="site-title">
										<a href="http://localhost/www/">
											streetlingua										</a>
									</h1>

									
									

									
								</div> <!-- /.site-title-tagline-wrapper -->

							
						</div> <!-- /.navbar-brand -->

					</div> <!-- /.navbar-header -->

						<nav class="navbar-collapse bs-navbar-collapse collapse" id="site-navigation" itemscope="" itemtype="http://schema.org/SiteNavigationElement">
		<ul class="nav navbar-nav navbar-right responsive-nav main-nav-list zerif-nav-menu-callback"><li class="page_item page-item-2 current_page_item"><a href="http://localhost/www/page-d-exemple/">Connexion</a></li>
</ul>	</nav>
	



				</div>

			</div>
						<!-- / END TOP BAR -->
	<div class="clear"></div>
</header> <!-- / END HOME SECTION  -->
	
<div id="content" class="site-content">
	<div class="container" style="min-height: 1px;">
				<div class="content-left-wrap col-md-9">	
				<div id="primary" class="content-area">
			<main itemscope="" itemtype="http://schema.org/WebPageElement" itemprop="mainContentOfPage" id="main" class="site-main">
				




	<header class="entry-header">

		
	
		<h1 class="entry-title" itemprop="headline">Inscription</h1>		
	</header><!-- .entry-header -->

	
	<div class="entry-content">

	<div id="col2">

<div id="inscription">


<?php



$connexion = mysqli_connect('localhost', 'user', 'password', 'wp_database');

if (isset($_POST['valider']))
{
	//on definit des variables pour leurs attribuer les messsages d'erreur qui peuvent apparaitre au cours de l'inscription
		$valide=true;
		$pseudo_erreur1 = NULL;
		$pseudo_erreur2 = NULL;
		$mdp_erreur = NULL;
		$message='';
		
		
		$login = mysqli_real_escape_string($connexion, $_POST['login']);
		$mdp = mysqli_real_escape_string($connexion, md5($_POST['password']));
		$confirm = mysqli_real_escape_string($connexion, md5($_POST['confirm']));
		$nom = mysqli_real_escape_string($connexion, $_POST['nom']);
		$prenom = mysqli_real_escape_string($connexion, $_POST['prenom']);
		$ad_email = mysqli_real_escape_string($connexion, $_POST['email']);
		$type = mysqli_real_escape_string($connexion, $_POST['type']);
		$jour = mysqli_real_escape_string($connexion, $_POST['jour']);
		$mois= mysqli_real_escape_string($connexion, $_POST['mois']);
		$annee = mysqli_real_escape_string($connexion, $_POST['annee']);
		$daten=$jour."/".$mois."/".$annee;
  //verif si tous les champs sont remplis
  
		if((empty($_POST['login']) and empty($_POST['password']) and empty($_POST['confirm']) and 
		empty($_POST['nom']) and empty($_POST['prenom'])and  empty($_POST['email']) and empty($_POST['type'])  and empty($_POST['mois']) 
		and empty($_POST['annee']) and 
		empty($_POST['jour'])  ))
		
			{?>
				<script>
				alert('veuillez rentrer tous les champs');
				</script>
				<?php
				$valide = false;
			}

			//on verifie si le login existe deja dans la base ou non. Comme le pseudo de chaque personne doit etre unique, on va demander a l'utilisateur 
//de choisir un autre

			$resultat = mysqli_query($connexion, 'SELECT user_login FROM  wp_users WHERE user_login=\''.$login.'\';');
			if($resultat == TRUE && mysqli_num_rows($resultat) != 0) 
			{
				$valide=false;
			}	
			
//on impose une condition sur la longueu du pseudo: pas plus long de 15 et plus court que 3, sinon un message d'erreur sera affiche
		
			if (strlen($login) < 3 || strlen($login) > 20)
			{
				$pseudo_erreur2 = "Votre pseudo est soit trop grand, soit trop petit";
				
				$valide=false;
			}
//verification du mot de passe: on compare le 2 champs pour voir si les mots de passe sont les memes

			if ($mdp != $confirm || empty($confirm) || empty($mdp))
			{
				$mdp_erreur = "Votre mot de passe et votre confirmation diffèrent, ou sont vides";
				$valide=false;
			}
			if ($valide==false) 
			{
				echo '<font color="red">';
				echo 'ERREUR mdp</br>';
				echo '</font>';
						
			}
			
			else {
	
			// requete insertion
			
			$rempli_u = "INSERT INTO wp_users (user_login, user_type, user_nom, user_prenom, user_date, user_pass, user_email, user_registered) 
			VALUES ('".$login."','".$type."','".$nom."','".$prenom."','".$daten."','".$mdp."','".$ad_email."','".date("Y-m-d")."');"; 
		
			$resInsert = mysqli_query($connexion, $rempli_u);			
//si le resultat renvoie une erreur, on l'affiche		
			if($resInsert == FALSE)
				{
			    echo " <p>Erreur lors de l'insertion de l'utilisateur !</p>";
				printf("Message d'erreur : %s\n", mysqli_error($connexion));
			    exit();
				}
				else 
				{
					//sinon on affiche un message de confirmation d'ajout, et on fait une redirection vers la page de connexion
					$_SESSION['login']=$login;
					
					$formulaireValide = TRUE;
					echo '<font color="green">';
					echo "<p>Confirmation de l'inscription: ".$login."</p></br>";
					if ($type == 'mentor') {
					echo "<p>Cliquez <a href='./ajout_annonce.php'> ici </a> pour ajouter une annonce</p>";
					}
					else echo "<p>Cliquez <a href='./tableau_de_bord.php'> ici </a> pour acceder au tableau de bord</p>";
					echo '</font>';
					
					//header('Refresh: 2; url=./connexion.php'); 
				}
			
		}
			
}
 else {
?>
<form method="post" action="#">
	
<table>
<tr>
	<td><label style="font-weight:bold"  for="login">Login :</label></td>
	<td><input name="login"  type="text" style=" border: 1px solid #A9A9A9;" id="login" /><br /></td>
</tr>
<tr>
	<td><label style="font-weight:bold"  for="type">Type :</label></td>
	<td><input type="radio" name="type" value="mentor"/>Mentor
    <input type="radio" name="type" value="apprenti"/>    Apprenti</td>
</tr>
<tr>
	<td><label style="font-weight:bold"  for="nom">Nom :</label></td>
	<td><input name="nom"  type="text" style=" border: 1px solid #A9A9A9;" id="nom" /><br /></td>
</tr>
<tr>
	<td><label style="font-weight:bold" for="prenom">Prenom :</label></td>
	<td><input type="prenom" name="prenom" style=" border: 1px solid #A9A9A9;" id="prenom" /></td>
</tr>
<tr>
		<td><label style="font-weight:bold" for="date_naiss">Date de naissance: </label> </td>
				<td> <select name="jour">
				<?php for ($jour = 1 ; $jour <= 31 ; $jour++)
		{
		?>
						  <option value="<?php echo $jour ?>"><?php echo $jour; ?></option>
		<?php              
		}
		?>  
		</select>
		<select name="mois">
				<?php for ($mois = 1 ; $mois <= 12 ; $mois++)
		{
		?>
						  <option value="<?php echo $mois ?>"><?php echo $mois; ?></option>
		<?php              
		}
		?>  
		</select>
		</select>
		<select name="annee">
				<?php for ($annee = 1900 ; $annee <= 2017 ; $annee++)
		{
		?>
						  <option value="<?php echo $annee ?>"><?php echo $annee; ?></option>
		<?php              
		}
		?>  
		</select> </td>
		</tr>
<tr>
	<td><label style="font-weight:bold"  for="email">Email :</label></td>
	<td><input name="email"  type="email" id="email" style=" border: 1px solid #A9A9A9;" /><br /></td>
</tr>
<tr>
	<td><label style="font-weight:bold"  for="password">Mot de Passe :</label></td>
	<td><input type="password" name="password"style=" border: 1px solid #A9A9A9;" id="password" /></td>
</tr>
<tr>
	<td><label style="font-weight:bold"  for="confirm">Confirmez le mot de passe :</label></td>
	<td><input type="password" name="confirm" style=" border: 1px solid #A9A9A9;" id="confirm" /></td>
</tr>

<tr style="text-align:center;">
			<td colspan=2><br/><br/>
			<input type="submit" name="valider" value="S'inscrire" />
			</td>
</tr>
<tr style="text-align:center;">
			<td colspan=2><br/><br/>
			<div class="choix">
			<a  href="./inscription.php">Pas encore inscrit ?</a> </div>
			</td>
</tr>
</table>
</form>
</div>

<?php } ?>
</div>


	</div>
	</article></main>
	</div>
	
		


</body></html>